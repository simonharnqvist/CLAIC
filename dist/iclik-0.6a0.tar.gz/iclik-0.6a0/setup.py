from setuptools import setup
import pypandoc

setup(
    name='iclik',
    version='0.06-alpha',
    packages=['iclik'],
    description="Information criteria for composite likelihood models",
)
