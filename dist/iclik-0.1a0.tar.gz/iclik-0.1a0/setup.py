from setuptools import setup

setup(
    name='iclik',
    version='0.01-alpha',
    packages=['iclik']
)